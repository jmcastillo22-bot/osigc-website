# Instrucciones de Implementación del Nuevo Sitio Web en WordPress

A continuación, se detallan los pasos para reemplazar el contenido de la página de inicio actual de `osigc.com` con el nuevo diseño, utilizando el código HTML y los archivos de recursos proporcionados.

**IMPORTANTE:** El nuevo sitio web es una aplicación moderna de React. Para que funcione correctamente dentro de WordPress, es crucial que se sigan estos pasos. El código HTML que se proporciona es un "cargador" que necesita los archivos CSS y JavaScript para renderizar el contenido.

## Paso 1: Subir los Archivos de Recursos (Assets)

1.  **Descomprima** el archivo adjunto `osigc_new_website_assets.zip`. Encontrará una carpeta llamada `assets` con todos los archivos CSS, JavaScript e imágenes.
2.  **Suba la carpeta `assets`** a una ubicación pública en su servidor de WordPress. La ubicación más recomendada es dentro de su tema actual (Enfold) o un tema hijo, por ejemplo:
    *   `wp-content/themes/enfold/new-osigc-assets/`
    *   *Alternativamente, puede usar un plugin de gestión de archivos o subirlo a través de FTP/cPanel.*
3.  **Determine la URL pública** de esta nueva carpeta. Por ejemplo, si sube la carpeta `assets` a la raíz de su tema, la URL será:
    *   `https://osigc.com/wp-content/themes/enfold/new-osigc-assets/assets/`

**Asegúrese de que la URL termine en `/assets/` y que todos los archivos dentro sean accesibles públicamente.**

## Paso 2: Modificar el Código HTML

El archivo `new_osigc_homepage.html` contiene el código base. Debe modificar las rutas de los archivos CSS y JavaScript para que apunten a la URL que determinó en el Paso 1.

### Código HTML Original:

```html
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/svg+xml" href="/assets/favicon-17051919.svg">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="OSI Global Consulting - Expertos en Transformación de la Cadena de Suministro. Planificación, Transformación y Ejecución de mejoras operacionales e implementaciones de sistemas (OMP, SAP S/4HANA, IFS) a nivel global.">
    <title>OSI Global Consulting - Supply Chain Transformation Experts</title>
    <script type="module" crossorigin="" src="/assets/index-81788737.js"></script>
    <link rel="stylesheet" crossorigin="" href="/assets/index-98282370.css">
</head>
<body>
    <div id="root"></div>
    <!-- Script de Cloudflare Insights, puede ser opcional -->
    <script defer="" src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c12417176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon="{&quot;version&quot;:&quot;2024.11.0&quot;,&quot;token&quot;:&quot;da771ba165764e14af0c1554ee13a638&quot;,&quot;r&quot;:1,&quot;server_timing&quot;:{&quot;name&quot;:{&quot;cfCacheStatus&quot;:true,&quot;cfEdge&quot;:true,&quot;cfExtPri&quot;:true,&quot;cfL4&quot;:true,&quot;cfOrigin&quot;:true,&quot;cfSpeedBrain&quot;:true},&quot;location_startswith&quot;:null}}" crossorigin="anonymous"></script>
</body>
</html>
```

### Código HTML Modificado (Ejemplo):

Reemplace `[URL_DE_SU_CARPETA_ASSETS]` con la URL real que obtuvo en el Paso 1.

```html
<!-- COMIENZO DEL CÓDIGO A PEGAR EN WORDPRESS -->
<div id="root"></div>
<script>
    // Desactivar el constructor de diseño de Enfold para esta página
    if (typeof avia_disable_builder_on_page !== 'undefined') {
        avia_disable_builder_on_page();
    }
</script>
<link rel="icon" type="image/svg+xml" href="[URL_DE_SU_CARPETA_ASSETS]/favicon-17051919.svg">
<script type="module" crossorigin="" src="[URL_DE_SU_CARPETA_ASSETS]/index-81788737.js"></script>
<link rel="stylesheet" crossorigin="" href="[URL_DE_SU_CARPETA_ASSETS]/index-98282370.css">
<!-- FIN DEL CÓDIGO A PEGAR EN WORDPRESS -->
```

## Paso 3: Implementar en WordPress

1.  **Acceda al panel de administración** de WordPress (`https://osigc.com/wp-admin`).
2.  Vaya a **Páginas** y edite la página de **Inicio** (Home).
3.  **Desactive el Avia Layout Builder** si está activo y cambie el editor al modo **"Texto"** (o "HTML").
4.  **Borre todo el contenido existente** en el editor.
5.  **Pegue el Código HTML Modificado** (solo la parte marcada como `COMIENZO DEL CÓDIGO A PEGAR EN WORDPRESS` hasta `FIN DEL CÓDIGO A PEGAR EN WORDPRESS`) en el editor de texto.
6.  **Guarde los cambios** y **Publique** la página.
7.  **Verifique** que el nuevo sitio web se muestra correctamente en `https://osigc.com`.

**Nota sobre el diseño:** El nuevo sitio web está diseñado para ocupar el 100% del ancho y alto de la pantalla. Para evitar que el tema Enfold agregue su propio encabezado, pie de página o barras laterales, es posible que deba configurar la plantilla de la página a **"No Header | No Footer"** o **"Blank Page"** si su tema lo permite.

Por favor, avíseme una vez que haya subido los archivos y esté listo para recibir el código HTML modificado. Le enviaré el archivo ZIP de assets y el HTML modificado en el siguiente mensaje.
